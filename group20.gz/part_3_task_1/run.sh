spark-submit --master $1 PageRank.py $2 $3
