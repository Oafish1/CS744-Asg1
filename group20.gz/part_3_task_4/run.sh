spark-submit --master $1 PageRank.py
