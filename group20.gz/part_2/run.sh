spark-submit --master $1 SimpleSort.py $2 $3
