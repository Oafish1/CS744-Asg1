# CS 744 Assignment 1 - Hadoop and Spark

`README` files are included in each section as well as a script `run.sh`.

The final report can be found as `group20.pdf`.

To use the scripts, `spark/bin` must be added to the path.
