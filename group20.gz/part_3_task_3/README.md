# Page Rank

First put the input file(s) into `hdfs`.

Then run the script on the main `spark` node
```bash
sh run.sh <master-node-spark-address> <input-file-location> <output-file-location>
```
